import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  AudioPlayer audioPlayer = AudioPlayer();
  AudioCache audioCache = AudioCache(prefix: "assets/audios/");
  String url = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3";

  _executar() async {
    /*int resultado = await audioPlayer.play(url);
      if (resultado == 1) {
         // successo
      }*/
    audioPlayer = await audioCache.play("musica.mp3");
  }

  _executarDog() async {
    audioPlayer = await audioCache.play("dog.mp3");
  }
  _executarCat() async {
    audioPlayer = await audioCache.play("cat.mp3");
  }
  _executarCow() async {
    audioPlayer = await audioCache.play("cow.mp3");
  }
  @override
  Widget build(BuildContext context) {
    //_executar();
    return Scaffold(
      appBar: AppBar(
        title: Text("Sons dos Animais"),
      ),
      body: Column(
        children: <Widget>[
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Padding(
                padding: EdgeInsets.all(8),
                child: GestureDetector(
                  child: Image.asset("assets/images/dog.png"),
                  onTap: (){
                    _executarDog();
                  },
                ),
              ),
              Padding(
                padding: EdgeInsets.all(8),
                child: GestureDetector(
                  child: Image.asset("assets/images/cat.png"),
                  onTap: (){
                    _executarCat();
                  },
                ),
              ),
              Padding(
                padding: EdgeInsets.all(8),
                child: GestureDetector(
                  child: Image.asset("assets/images/cow.png"),
                  onTap: (){
                    _executarCow();
                  },
                ),
              ),
            ],
          )
        ],
      ),
    );
  }
}
