import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  AudioPlayer audioPlayer = AudioPlayer();
  AudioCache audioCache = AudioCache(prefix: "assets/audios/");
  bool primeiraExecucao = true;
  double volume = 0.5;

  _executar() async {
    audioPlayer.setVolume(volume); //quando o usuário clicar no player, terei a primeira definição de volume
    if(primeiraExecucao == true){
      audioPlayer = await audioCache.play("musica.mp3");
      primeiraExecucao = false;
    } else{
      audioPlayer.resume(); // continua e execução a partir do ponto que foi pausado
    }
  }
  _pausar() async{
    int resultado = await audioPlayer.pause();
    if(resultado == 1){
      //sucesso
    }
  }

  _parar() async{
    int resultado = await audioPlayer.stop();
    if(resultado == 1){
      //sucesso
    }
  }

  @override
  Widget build(BuildContext context) {
    //_executar();
    return Scaffold(
      appBar: AppBar(
        title: Text("Sons Player"),
      ),
      body: Column(
        children: <Widget>[
          Padding(
            padding: EdgeInsets.all(8),
          ),
          Slider(
              value: volume,
              min: 0,
              max: 1,
              divisions: 10,
              onChanged: (novoVolume){
                setState(() {
                  volume = novoVolume;
                });
                audioPlayer.setVolume(novoVolume);
              }
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Padding(
                padding: EdgeInsets.all(8),
                child: GestureDetector(
                  child: Image.asset("assets/images/executar.png"),
                  onTap: (){
                    _executar();
                  },
                ),
              ),
              Padding(
                padding: EdgeInsets.all(8),
                child: GestureDetector(
                  child: Image.asset("assets/images/pausar.png"),
                  onTap: (){
                    _pausar();
                  },
                ),
              ),
              Padding(
                padding: EdgeInsets.all(8),
                child: GestureDetector(
                  child: Image.asset("assets/images/parar.png"),
                  onTap: (){
                    _parar();
                  },
                ),
              ),
            ],
          )
        ],
      ),
    );
  }
}