import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  VideoPlayerController _videocontroller;

  @override
  void initState() {
    super.initState();
    /*_videocontroller = VideoPlayerController.network(
      "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4")
      ..initialize().then((_){});//não será recuperado o retorno do initialize usando dois pontos
      //then é usado para fazer mais algo apos a inicialização do video
      //usamos o underline, pois não estou querendo usar o parâmetro
      setState(() {
        _videocontroller.play();
      });*/
    _videocontroller = VideoPlayerController.asset(
        "assets/videos/exemplo.mp4")
      ..setLooping(true)
      ..initialize().then((_) {
        _videocontroller.play();
      });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: AspectRatio(
          aspectRatio: _videocontroller.value.aspectRatio, //vai deixar o vídeo com um tamanho bom
          child: VideoPlayer(_videocontroller),
        ),
      ),
    );
  }
}
